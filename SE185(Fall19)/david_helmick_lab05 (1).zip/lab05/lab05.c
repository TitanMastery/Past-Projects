/*----------------------------------------------------------------------------
-		         SE 185: Lab 05 - Conditionals (What's up?)	    	         -
-	Name:																	 -
- 	Section:																 -
-	NetID:																     -
-	Date:																	 -
-----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
-								Includes									 -
-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <math.h>

/*----------------------------------------------------------------------------
-	                            Prototypes                                   -
-----------------------------------------------------------------------------*/
double magnitude(double x, double y, double z);
int closeTo(double tolerance, double point, double value);
int getDirection(double x, double y, double z);
void printDirection(int direction);

/*----------------------------------------------------------------------------
-	                                Notes                                    -
-----------------------------------------------------------------------------*/
// Compile with gcc lab05.c -o lab05
// Run with ./ds4rd.exe -d 054c:05c4 -D DS4_BT -a -g -b | ./lab05

/*----------------------------------------------------------------------------
-								Implementation								 -
-----------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    int triangle, circle, x_button, square;
    double ax, ay, az, gx, gy, gz;
	int tFlag=0;
	double aPoint=0.0;
	double aTolerance=0.001;
	double aMagnitude;
	int currentDirection,newDirection;

    while (!tFlag)
    {
        scanf("%lf, %lf, %lf, %lf, %lf, %lf, %d, %d, %d, %d",
              &ax, &ay, &az, &gx, &gy, &gz, &triangle, &circle, &x_button, &square);

        /* printf for observing values scanned in from ds4rd.exe,
         * be sure to comment or remove in final program */
        /*printf("Echoing output: %lf, %lf, %lf, %lf, %lf, %lf, %d, %d, %d, %d \n",
               ax, ay, az, gx, gy, gz, triangle, circle, x_button, square);
		*/
		
		aMagnitude=magnitude(ax, ay, az);
		
		if(closeTo(aTolerance,aPoint,aMagnitude)){
			newDirection=getDirection(gx,gy,gz);
			if(newDirection!=currentDirection){
				currentDirection=newDirection;
				printDirection(currentDirection);
			}
		}
		
		if(triangle==1){
			tFlag=1;
		}
    }

    return 0;
}

/* Put your functions here, and be sure to put prototypes above. */
double magnitude(double x, double y, double z){
    return sqrt(pow(x,2)+pow(y,2)+pow(z,2));
}

int closeTo(double tolerance, double point, double value){
	if(fabs(point-value)<=tolerance||fabs(value-point)<=tolerance){
		return 1;
	}else{
		return 0;
	}
}

int getDirection(double x, double y, double z){
	double gPositive=1.0;
	double gNegative=-1.0;
	double gTolerance=0.3;
	int xPositive,yPositive,zPositive,xNegative,yNegative,zNegative;
	
	xPositive=closeTo(gTolerance,gPositive,x);
	yPositive=closeTo(gTolerance,gPositive,y);
	zPositive=closeTo(gTolerance,gPositive,z);
	
	xNegative=closeTo(gTolerance,gNegative,x);
	yNegative=closeTo(gTolerance,gNegative,y);
	zNegative=closeTo(gTolerance,gNegative,z);
	
	if(xPositive){
		return 0;
	}else if(xNegative){
		return 1;
	}else if(yPositive){
		return 2;
	}else if(yNegative){
		return 3;
	}else if(zPositive){
		return 4;
	}else if(zNegative){
		return 5;
	}
}

void printDirection(int direction){
	char directions[6][10]={"Left","Right","Top","Bottom","Back","Front"};
	printf("%s\n",directions[direction]);
}