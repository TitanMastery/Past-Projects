/*---------------------------------------------------------------------------
-		        SE 185: Lab 08 - The A-Mazing DS4 Race - Part 2             -
-	Name:                                                                   -
- 	Section:                                                                -
-	NetID:                                                                  -
-	Date:                                                                   -
----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
-								Includes
-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <math.h>
#include <ncurses/ncurses.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

/*----------------------------------------------------------------------------
-								Defines	    								 -
-----------------------------------------------------------------------------*/
/*
 * Screen geometry:
 * Use ROWS and COLUMNS for the screen height and width
 * (set by the system). These are the maximums.
 */
#define COLUMNS 100
#define ROWS 80

/* Character definitions taken from the ASCII table */
#define AVATAR 'A'
#define WALL '*'
#define EMPTY_SPACE ' '

/*
 * Number of samples taken to form a moving average
 * for the gyroscope data. Feel free to modify this.
 */
#define LENGTH_OF_AVERAGE 250

/*-----------------------------------------------------------------------------
-								Static Data
-----------------------------------------------------------------------------*/
/* 2D character array which the maze is mapped into */
char MAZE[COLUMNS][ROWS];

/*-----------------------------------------------------------------------------
-								Prototypes
-----------------------------------------------------------------------------*/
void generate_maze(int difficulty);

void draw_maze();

void draw_character(int row, int column, char use);

double moving_average(double buffer[], int average_size, double new_item);

int detect_failure(int avatar_row, int avatar_column);

/*----------------------------------------------------------------------------
-	                                Notes                                    -
-----------------------------------------------------------------------------*/
// Compile with gcc lab08-2.c -o lab08-2 -lncurses
// Run with ./ds4rd.exe -d 054c:05c4 -D DS4_BT -t -g -b | ./lab08-2 { difficulty }
// NO GLOBAL VARIABLES ARE ALLOWED!

/*----------------------------------------------------------------------------
-								Implementation                               -
-----------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    /* Place your variables here. */
	int currentTime,startTime,timeMoved,tempCol;
	int triangle=0;
	double dtemp,newVal,average;
	int timeLimit = 500;
	int row=0;
	int col=50;
	int difficulty,temp;
	double buffer[LENGTH_OF_AVERAGE];
	int endGame=0;

    sscanf(argv[1], "%d", &difficulty);
    if (difficulty < 0 || difficulty > 100)
    {
        printf("The difficulty level must be between 0 and 100.\n"
               "Rerun the command line with a valid difficulty level.\n");
        return 0;
    }

    /*
     * Setup screen for ncurses:
     * The initscr() function is used to setup the ncurses environment.
     * The refresh() function needs to be called to update the screen
     * with any changes you've created. */
    initscr();
    refresh();

    /* WEEK 2 Generate the Maze */
	generate_maze(difficulty);
	draw_maze();
	
    /* Read gyroscope data and fill the buffer before continuing. */
	for(int i=0;i<LENGTH_OF_AVERAGE;i++){
		scanf("%d, %lf, %lf, %lf, %d, %d, %d, %d",&startTime,&buffer[i],&dtemp,&dtemp,&temp,&temp,&temp,&temp);
	}
	draw_character(col, row, AVATAR);
	/* Event loop */
    do
    {
        /* Read data, update average */
		scanf("%d, %lf, %lf, %lf, %d, %d, %d, %d",&currentTime,&newVal,&dtemp,&dtemp,&triangle,&temp,&temp,&temp);
		if(triangle){
			endwin();
			printf("YOU QUIT!\n");
			return 0;
		}
		average=moving_average(buffer,LENGTH_OF_AVERAGE,newVal);
		if(currentTime-timeMoved>100){
			draw_character(col, row, EMPTY_SPACE);
			tempCol=col-round(average);
			if(tempCol>COLUMNS){
				col=COLUMNS;
			}
			else if(tempCol<0){
				col=0;
			}
			else if(MAZE[tempCol][row]==WALL){
				col=col;
			}
			else{
				col=tempCol;
			}
			draw_character(col, row, AVATAR);
			timeMoved=currentTime;
		}
        /* Is it time to move?  if so, then move avatar */
		if(currentTime-startTime>timeLimit){
			if(MAZE[col][row+1]!=WALL){
				draw_character(col, row, EMPTY_SPACE);
				row++;
				draw_character(col, row, AVATAR);
			}
			startTime=currentTime;
		}
		if(detect_failure(row, col)){
			endwin();
			printf("YOU LOSE!\n");
			return 0;
		}
		if(row==80){
			endGame=1;
		}
    } while (!endGame); // Change this to end game at right time

    /* Print the win/loss message */


    /*
     * This function is used to cleanup the ncurses environment.
     * Without it, the characters printed to the screen will
     * persist even after the program terminates. */
    endwin();

    printf("YOU WIN!\n");
}

/**
 * POST: Generates a random maze structure into MAZE[][].
 * You will want to use the rand() function and maybe use the output %100.
 * You will have to use the argument to the command line to determine how
 * difficult the maze is (how many maze characters are on the screen).
 *
 * @param difficulty - The percentage of the MAZE to be covered in walls.
 */
void generate_maze(int difficulty)
{
	srand(time(NULL));
	int i,j;
	for(i=0;i<=COLUMNS;i++){
		for(j=0;j<=ROWS;j++){
			if((rand()%100)<=difficulty){
				MAZE[i][j] = WALL;
			}
			else{
				MAZE[i][j] = EMPTY_SPACE;
			}
		}
	}
}

/**
 * PRE: MAZE[][] has been initialized by generate_maze().
 * POST: Draws the maze to the screen.
 */
void draw_maze()
{
	int i,j;
	for(i=0;i<=COLUMNS;i++){
		for(j=0;j<=ROWS;j++){
			draw_character(i,j,MAZE[i][j]);
		}
	}
}

/**
 * PRE: 0 < x < COLUMNS, 0 < y < ROWS, 0 < use < 255.
 * POST: Draws character use to the screen and position x, y.
 * THIS CODE FUNCTIONS FOR PLACING THE AVATAR AS PROVIDED.
 * DO NOT MODIFY THIS FUNCTION!
 *
 * @param row - The row in which the character "use" will be drawn.
 * @param column - The column in which the character "use" will be drawn.
 * @param use - The character that is to be drawn in the MAZE.
 */
void draw_character(int row, int column, char use)
{
    mvaddch(column, row, use);
    refresh();
}

/**
 * Updates the buffer (that determines orientation) with the new_item
 * and returns the computed moving average of the updated buffer.
 *
 * @param buffer - An array of doubles used to hold the values that determine the average.
 * @param average_size - The size of your buffer.
 * @param new_item - The new element to be placed into the array.
 * @return - The moving average of the values in the buffer (your array).
 */
double moving_average(double buffer[], int average_size, double new_item)
{
	double increment = 0;
	int i;
	for(i = 0; i < average_size - 1; i++){
		buffer[i] = buffer[i+1];
		increment += buffer[i];
	}
	buffer[i] = new_item;
	increment += buffer[i];
	return (increment/average_size);
}

/**
 * Detect if the AVATAR is in a position in which it is impossible
 * to reach the bottom of the MAZE and win the game.
 *
 * @param row - The coordinate of the row in which the AVATAR is currently positioned.
 * @param column - The coordinate of the column in which the AVATAR is currently positioned.
 * @return - True if failure has occurred and you have lost the game. Otherwise, False.
 */
int detect_failure(int avatar_row, int avatar_column)
{
	
	int wallLeft,wallRight;
	wallLeft=-1;
	wallRight=-1;
	for(int k=avatar_column;k>=0;k--){
		if(MAZE[k][avatar_row]==WALL && wallLeft==-1){
			wallLeft=k;
		}
	}
	for(int l=avatar_column;l<=COLUMNS;l++){
		if(MAZE[l][avatar_row]==WALL && wallRight==-1){
			wallRight=l;
		}
	}
	if(wallLeft!=-1&&wallRight!=-1){
		int x;
		for(x=wallLeft+1;x<wallRight;x++){
			if(MAZE[x][avatar_row+1]!=WALL){
				break;
			}
		}
		if(x==wallRight){
			return 1;
		}
	}
	else{
		int x;
		for(x=0;x<=COLUMNS;x++){
			if(MAZE[x][avatar_row+1]!=WALL){
				break;
			}
		}
		if(x>COLUMNS){
			return 1;
		}
	}
	return 0;
}
