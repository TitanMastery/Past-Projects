/*---------------------------------------------------------------------------
-					   SE 185: Lab 07 - The DS4 Equalizer                   -
-	Name:                                                                   -
- 	Section:                                                                -
-	NetID:                                                                  -
-	Date:                                                                   -
-                                                                           -
-   This file provides the outline for your program.                        -
-   Please implement the functions given by the prototypes below and        -
-   complete the main function to make the program complete.                -
-   You must implement the functions which are prototyped below exactly     -
-   as they are prototyped.                                                 -
----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
-								Includes									 -
-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>

/*----------------------------------------------------------------------------
-	                            Prototypes                                   -
-----------------------------------------------------------------------------*/
void read_input(double *gx, double *gy, double *gz, int *triangle,
                int *circle, int *x_button, int *square, int *left_joy_x_axis,
                int *left_joy_y_axis, int *right_joy_x_axis, int *right_joy_y_axis);

int scale_gyro_for_screen(double gyro_value);

int scale_joy_for_screen(int joy_value);

void print_chars(int number, char char_to_print);

void graph_line(int number, int current_mode);

/*----------------------------------------------------------------------------
-	                                Notes                                    -
-----------------------------------------------------------------------------*/
// Compile with gcc lab07.c -o lab07
// Run with ./ds4rd.exe -d 054c:05c4 -D DS4_BT -g -b -j | ./lab07
// GLOBAL VARIABLES ARE NOT ALLOWED!!!

/*-----------------------------------------------------------------------------
-								Implementation
-----------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    double gx, gy, gz;                              /* Values of gx, gy, and gz axis            */

    int triangle, circle, x_button, square,         /* Variables to hold the button statuses    */

            left_joy_x_axis, left_joy_y_axis,       /* Variables to hold the joystick statuses  */
            right_joy_x_axis, right_joy_y_axis,

            scaled_gyro_pitch, scaled_gyro_roll,    /* Value of the roll/pitch of the gyroscope
                                                       adjusted to fit screen display           */

            scaled_joy_pitch, scaled_joy_roll;      /* Value of the roll/pitch of the joystick
                                                       adjusted to fit screen display           */

    /* Put pre-loop preparation code here */
	int current_mode = 0;

    do
    {
        /* Scan a line of input. */
		read_input(&gx, &gy, &gz, &triangle, &circle, &x_button, &square, &left_joy_x_axis, &left_joy_y_axis, &right_joy_x_axis, &right_joy_y_axis);

        /* Calculate and scale for pitch AND roll AND joystick. */
		scaled_gyro_pitch = scale_gyro_for_screen(gz);
		
		scaled_gyro_roll = scale_gyro_for_screen(gx);
		
		scaled_joy_pitch = scale_joy_for_screen(left_joy_y_axis);
		
		scaled_joy_roll = scale_joy_for_screen(left_joy_x_axis);

        /* Switch between roll, pitch, and joystick with the up, down, and right button, respectively. */
		if(circle){
			current_mode++;
			if(current_mode>3){
				current_mode = 0;
			}
			while(circle){
				read_input(&gx, &gy, &gz, &triangle, &circle, &x_button, &square, &left_joy_x_axis, &left_joy_y_axis, &right_joy_x_axis, &right_joy_y_axis);
			}
		}
        /* Output your graph line. */
		switch(current_mode){
			case 0:
				graph_line(scaled_gyro_roll, current_mode);
				break;
			case 1:
				graph_line(scaled_gyro_pitch, current_mode);
				break;
			case 2:
				graph_line(scaled_joy_roll, current_mode);
				break;
			case 3:
				graph_line(scaled_joy_pitch, current_mode);
				break;
		}

        fflush(stdout);

    } while (!triangle); /* Modify to stop when Triangle is pressed */

    return 0;

}

/**
 * PRE: Arguments must point to double variables or int variables as appropriate.
 * This function scans a line of DS4 data. It's essentially a convoluted way of
 * doing your standard DS4 scan statement, but it's a basic practice in pointers.
 * POST: it modifies its arguments to return values read from the input line.
 */
void read_input(double *gx, double *gy, double *gz, int *triangle,
                int *circle, int *x_button, int *square, int *left_joy_x_axis,
                int *left_joy_y_axis, int *right_joy_x_axis, int *right_joy_y_axis)
{
	scanf("%lf, %lf, %lf, %d, %d, %d, %d, %d, %d, %d, %d", 
			gx, gy, gz, triangle, circle, x_button, square, left_joy_x_axis,
			left_joy_y_axis, right_joy_x_axis, right_joy_y_axis);
}

/**
 * PRE: ~(-1.0) <= gyro_value <= ~(1.0)
 * This function scales the roll/pitch value of the gyroscope to
 * fit on the screen. Input should be capped at either -1.0 or 1.0
 * before the rest of your conversion.
 * POST: -39 <= return value <= 39
 *
 * @param gyro_value - The appropriate gyroscope value for printing characters.
 * @return - The amount of characters that should be printed.
 */
int scale_gyro_for_screen(double gyro_value)
{
	return (int)(gyro_value*39);
}

/**
 * PRE: -128 <= mag <= 127
 * This function scales the joystick value to fit on the screen.
 * POST: -39 <= return value <= 39
 *
 * @param joy_value - The appropriate joystick value for printing characters.
 * @return - The amount of characters that should be printed.
 */
int scale_joy_for_screen(int joy_value)
{
	double num=(double)joy_value/128*39;
	return (int)num;
}

/**
 * PRE: number >= 0
 * This function prints the character "use" to the screen "num" times.
 * This function is the ONLY place printf is allowed to be used nothing.
 * POST: nothing is returned, but "char_to_print" has been printed "num" times.
 *
 * @param number - The amount of characters to print.
 * @param char_to_print - The character that should be printed.
 */
void print_chars(int number, char char_to_print)
{
	for(int i = number; i > 0; i--){
		printf("%c", char_to_print);
	}
}

/**
 * PRE: -39 <= number <= 39
 * Uses print_chars to graph a number from -39 to 39 on the screen.
 * You may assume that the screen is 80 characters wide.
 *
 * @param number - The amount of characters that are to be printed.
 * @param current_mode - The current mode the program is in.
 *                       {0:gyro_roll, 1:gyro_pitch, 2:joy_roll, 3:joy_pitch}
 */
void graph_line(int number, int current_mode)
{
	if(number == 0){
		print_chars(39, ' ');
		print_chars(1, '0');
	}
	else if(current_mode%2){
		if(number < 0){
			print_chars(39+number, ' ');
			print_chars(abs(number), 'F');
		}
		else{
			print_chars(40, ' ');
			print_chars(number, 'B');
		}
	}
	else if(current_mode == 2){
		if(number < 0){
			print_chars(39+number, ' ');
			print_chars(abs(number), 'L');
		}
		else{
			print_chars(40, ' ');
			print_chars(number, 'R');
		}
	}
	else{
		if(number > 0){
			print_chars(39-number, ' ');
			print_chars(number, 'L');
		}
		else{
			print_chars(40, ' ');
			print_chars(abs(number), 'R');
		}
	}
	print_chars(1, '\n');
}
