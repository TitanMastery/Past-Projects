/*----------------------------------------------------------------------------
-		    SE 185: Lab 03 - Introduction to the DS4 and Functions	    	 -
-	Name:																	 -
- 	Section:																 -
-	NetID:																     -
-	Date:																	 -
-----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
-								Includes									 -
-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <math.h>

/*----------------------------------------------------------------------------
-	                            Prototypes                                   -
-----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------
-	                                Notes                                    -
-----------------------------------------------------------------------------*/
// Compile with gcc lab03-2.c -o lab03-2
// Run with ./ds4rd.exe -d 054c:05c4 -D DS4_BT -b | ./lab03-2

/*----------------------------------------------------------------------------
-								Implementation								 -
-----------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
	int t,c,x,s;
	
    while (1)
    {
		scanf("%d, %d, %d, %d", &t, &c, &x, &s);
		
		printf("Buttons Pressed: %d\n", Counter(t,c,x,s));
		fflush(stdout);
    }

    return 0;
}

/* Put your functions here, and be sure to put prototypes above. */
int Counter(int t, int c, int x, int s){
	int buttonCounter=0;
	if(t==1){
		buttonCounter++;
	}
	if(c==1){
		buttonCounter++;
	}
	if(x==1){
		buttonCounter++;
	}
	if(s==1){
		buttonCounter++;
	}
	return buttonCounter;
}
