/*-------/---------------------------------------------------------------------
-		        SE 185: Lab 02 - Solving Simple Problems in C	    	 	 -
-	Name:David Helmick														 -
- 	Section:1																 -
-	NetID:dhelmick														     -
-	Date:9/13/19															 -
-----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
-								Includes									 -
-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <math.h>

/*----------------------------------------------------------------------------
-								Implementation								 -
-----------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    /* Put your code after this line */
	int a=6427 + 1725;
	printf("6427 + 1725 = %d\n",a);
	
	int b=(6971 * 3925)-95;
	printf("(6971 * 3925) – 95 = %d\n",b);
	
	double c=79 + 12 / 5;
	printf("79 + 12 / 5 = %.2lf\n",c);
	
	double d=3640.0 / 107.9;
	printf("3640.0 / 107.9 = %.2lf\n",d);
	
	int e=(22 / 3) * 3;
	printf("(22 / 3) * 3 = %d\n",e);
	
	int f=22 / (3 * 3);
	printf("22 / (3 * 3) = %d\n",f);
	
	double g=22 / (3 * 3);
	printf("22 / (3 * 3) = %.2lf\n",g);
	
	double h=22 / 3* 3;
	printf("22 / 3* 3 = %.2lf\n",h);
	
	double i=(22.0 / 3) * 3.0;
	printf("(22.0 / 3) * 3.0 = %.2lf\n",i);
	
	int j=22.0 / (3 * 3.0);
	printf("22.0 / (3 * 3.0) = %d\n",j);
	
	double k=22.0 / 3.0 * 3.0;
	printf("22.0 / 3.0 * 3.0 = %.2lf\n",k);
	
	double l=M_PI*pow((23.567/M_PI)/2,2);
	printf("The area of a circle with a circumference of 23.567 is %.2lf\n",l);
	
	double m=14.0*0.3048;
	printf("Fourteen feet in meters is %.2lf\n",m);
	
	double n=(76-32)/1.8;
	printf("76 degrees Fahrenheit is %.2lf degrees Celsius",n);
	
    return 0;
}