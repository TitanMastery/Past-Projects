/*-------/---------------------------------------------------------------------
-		        SE 185: Lab 02 - Solving Simple Problems in C	    	 	 -
-	Name:David Helmick														 -
- 	Section:1																 -
-	NetID:dhelmick														     -
-	Date:9/13/19															 -
-----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
-								Includes									 -
-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <math.h>

/*----------------------------------------------------------------------------
-								Implementation								 -
-----------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    /* Put your code after this line */
	int x,y,z;
	printf("Enter a width: ");
	scanf("%d",&x);
	printf("Enter a height: ");
	scanf("%d",&y);
	printf("Enter a depth: ");
	scanf("%d",&z);
	printf("A %d by %d by %d rectangular prism's area is %d\n",x,y,z,x*y*z);
	
    return 0;
}
