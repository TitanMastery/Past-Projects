/*----------------------------------------------------------------------------
-		        SE 185: Lab 02 - Solving Simple Problems in C	    	 	 -
-	Name:																	 -
- 	Section:																 -
-	NetID:																     -
-	Date:																	 -
-----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
-								Includes									 -
-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <math.h>   // Google this header file to learn more! :)

/*----------------------------------------------------------------------------
-								Implementation								 -
-----------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    double a, b, c;

    /* Put your code after this line */
	printf("Enter side a: ");
	scanf("%lf",&a);
	
	printf("Enter side b: ");
	scanf("%lf",&b);
	
    c = sqrt(pow(a,2)+pow(b,2));
	printf("Side c = %.2lf",c);

    return 0;
}
