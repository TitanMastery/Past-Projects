/*----------------------------------------------------------------------------
-		                    SE 185: Lab 06 - Bop-It!	    	             -
-	Name:																	 -
- 	Section:																 -
-	NetID:																     -
-	Date:																	 -
-----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
-								Includes									 -
-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*----------------------------------------------------------------------------
-	                            Prototypes                                   -
-----------------------------------------------------------------------------*/
int whichButton(int t, int c, int x, int s);
void wait();

/*----------------------------------------------------------------------------
-	                            Notes                                        -
-----------------------------------------------------------------------------*/
// Compile with gcc lab06.c -o lab06
// Run with ./ds4rd.exe -d 054c:05c4 -D DS4_BT -t -b | ./lab06

/*----------------------------------------------------------------------------
-								Implementation								 -
-----------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    srand(time(NULL)); /* This will ensure a random game each time. */
	
	int circlePressed=0;
	int temp, button, timeInitial, timeCurrent, userInput, triangle, circle, cross, square;
	int timeLimit=2500;
	int playing;
	int roundCounter=0;
	
	printf("This is a Bop-It Game!\n");
	printf("Please press the Circle Button to begin!\n\n");
	
	while(!circlePressed){
		scanf("%d, %d, %d, %d, %d", &temp, &temp, &circlePressed, &temp, &temp);
		playing=1;
	}
	
	wait();
	
	while(playing){
		button=(rand()%4)+1;
		switch(button){
			case 1:
				printf("Press the triangle button!\n");
				break;
			case 2:
				printf("Press the circle button!\n");
				break;
			case 3:
				printf("Press the cross button!\n");
				break;
			case 4:
				printf("Press the square button!\n");
				break;
			default:
				printf("Error: %d\n",button);
		}
		printf("You have %d milliseconds to respond!\n\n", timeLimit);
		scanf("%d, %d, %d, %d, %d", &timeCurrent, &temp, &temp, &temp, &temp);
		timeInitial=timeCurrent;
		while(timeCurrent - timeInitial < timeLimit){
			scanf("%d, %d, %d, %d, %d", &timeCurrent, &triangle, &circle, &cross, &square);
			userInput=whichButton(triangle, circle, cross, square);
			if(userInput==0){
				continue;
			}
			else if(userInput!=button){
				playing=0;
				printf("Wrong Button! :(\n");
				printf("You Lose!\n");
				break;
			}
			else if(userInput==button){
				timeLimit-=100;
				roundCounter++;
				break;
			}
		}
		if(!(timeCurrent - timeInitial < timeLimit)){
			playing=0;
			printf("You ran out of time. :(\n");
			printf("Thanks for playing!\n");
		}
		wait();
	}
	
	printf("You made it through %d rounds!\n", roundCounter);
	
    return 0;
}

/* Put your functions here, and be sure to put prototypes above. */
int whichButton(int t, int c, int x, int s){
	if(t==1){
		return 1;
	}
	else if(c==1){
		return 2;
	}
	else if(x==1){
		return 3;
	}
	else if(s==1){
		return 4;
	}
	else{
		return 0;
	}
}

void wait(){
	int t,c,x,s,temp;
	scanf("%d, %d, %d, %d, %d", &temp, &t, &c, &x, &s);
	while(t||c||x||s){
		scanf("%d, %d, %d, %d, %d", &temp, &t, &c, &x, &s);
	}
}