/*---------------------------------------------------------------------------
-		                SE 185: Lab 09 - The DS4Talker                      -
-	Name:                                                                   -
- 	Section:                                                                -
-	NetID:                                                                  -
-	Date:                                                                   -
----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
-								Includes									 -
-----------------------------------------------------------------------------*/
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ncurses/ncurses.h>

/*----------------------------------------------------------------------------
-								Defines	    								 -
-----------------------------------------------------------------------------*/
#define MAX_WORD_LENGTH 12 /* The maximum length a word can be. */
#define MAX_WORDS 75 /* The maximum words that can be in the DS4Talker. */

/*----------------------------------------------------------------------------
-	                            Prototypes                                   -
-----------------------------------------------------------------------------*/
void trim_whitespace(char *string);

int read_words(char *word_list[MAX_WORDS], char *file_name);

void scanVal(int *time,int *triangle,int *circle,int *cross,int *square,int *options,int *share,int *r2,int *l2,int *up,int *left,int *down,int *right);

void wait();

void clearSentence();

void capitalize(int caps, char currentWord[MAX_WORD_LENGTH]);

void printCaps(int caps);

/*----------------------------------------------------------------------------
-	                                Notes                                    -
-----------------------------------------------------------------------------*/
// Compile with gcc lab09.c -o lab09 -lncurses
// Run with ./ds4rd.exe -d 054c:05c4 -D DS4_BT -t -b -bt -bd | ./lab09 word_list.txt
// NO GLOBAL VARIABLES ARE ALLOWED!

/*----------------------------------------------------------------------------
-								Implementation                               -
-----------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    //variable declarations
	char *word_list[MAX_WORDS];
    int word_count = read_words(word_list, argv[1]);
    int i,j,k;
    initscr();
	int row,col;
	int caps=0;
	int time,triangle,circle,cross,square,temp,options=0,share=0,r2,l2,up,left,down,right;
	char sentence[80];
	int lengths[79];
	int lengthPos=-1;
	char currentWord[MAX_WORD_LENGTH];

    
	//Loops through the lsit of words and prints them to the screen
	i=0;
	word_list[0]="the";
	for(j=0;j<word_count/5;j++){
		for(k=1;k<=5;k++){
			mvprintw(j,k*MAX_WORD_LENGTH,"%s",word_list[i]);
			i++;
		}
	}
	
	
	//Sets default values for row, col, and sentence; then prints asterisk to the screen
	row=0;
	col=MAX_WORD_LENGTH-1;
	mvaddch(row,col,'*');
	refresh();
	strcpy(sentence,"");
	
	
	//The rest of the program runs in this while loop which controls when the program ends
	while(!options&&!share){
		//runs scanVal function to populate variables with updated data
		scanVal(&time,&triangle,&circle,&cross,&square,&options,&share,&r2,&l2,&up,&left,&down,&right);
		
		//These four if statements control movement using the directional pad and updates the asterisk to the correct location on the screen
		if(down&&row!=14){
			mvaddch(row,col,' ');
			row++;
			mvaddch(row,col,'*');
			wait();
		}
		if(up&&row!=0){
			mvaddch(row,col,' ');
			row--;
			mvaddch(row,col,'*');
			wait();
		}
		if(left&&col!=MAX_WORD_LENGTH-1){
			mvaddch(row,col,' ');
			col-=MAX_WORD_LENGTH;
			mvaddch(row,col,'*');
			wait();
		}
		if(right&&col!=5*MAX_WORD_LENGTH-1){
			mvaddch(row,col,' ');
			col+=MAX_WORD_LENGTH;
			mvaddch(row,col,'*');
			wait();
		}
		
		//Copies the selected word into the currentWord variable
		strcpy(currentWord,word_list[row*5+col/MAX_WORD_LENGTH]);
		
		//Adds the currentWord to the sentence with the required formating(capitalization and spacing)
		if(square&&strlen(sentence)+strlen(currentWord)<80){
			lengthPos++;
			lengths[lengthPos]=strlen(currentWord);
			capitalize(caps,currentWord);
			strcat(sentence,currentWord);
			wait();
		}
		if(triangle&&strlen(sentence)+strlen(currentWord)+1<80){
			lengthPos++;
			lengths[lengthPos]=strlen(currentWord);
			capitalize(caps,currentWord);
			strcat(sentence," ");
			strcat(sentence,currentWord);
			wait();
		}
		
		//Runs clearSentence and sets sentence to an empty string when R2 or L2 is pressed
		if(r2||l2){
			clearSentence();
			strcpy(sentence,"");
		}
		
		//Handles whether to capitalize or not by incrementing a caps to 0, 1, or 2 then runs printCaps
		if(circle){
			if(caps<2){
				caps++;
			}
			else{
				caps=0;
			}
			printCaps(caps);
			wait();
		}
		
		//Removes words from the sentence according to the word lengths stored in lengths[]
		if(cross&&strlen(sentence)!=0){
			int length=lengths[lengthPos];
			for(int y=length;y>0;y--){
				sentence[strlen(sentence)-y]=' ';
			}
			lengthPos--;
			mvprintw(16,MAX_WORD_LENGTH,"%s",sentence);
			trim_whitespace(sentence);
			wait();
		}
		
		//Prints the sentence and refreshes lncurses
		mvprintw(16,MAX_WORD_LENGTH,"%s",sentence);
		refresh();
	}
	//ends lncurses and ends the program
	endwin();
    return 0;
}

/**
 * Modifies the given string to trim white space off at the end.
 * DO NOT MODIFY THIS FUNCTION.
 *
 * @param string - The string to ensure has no whitespace.
 */
void trim_whitespace(char *string)
{
    int length = strlen(string);
    if (length == 0) return;

    int i = length - 1;
    while (isspace(string[i]) && i >= 0)
    {
        string[i] = '\0';
        i--;
    }
}

/**
 * Reads words from the given file into word_list.
 * DO NOT MODIFY THIS FUNCTION.
 *
 * @param word_list - The list of words where the words taken from the given
 *                    file will be placed.
 * @param file_name - The name of the file to read from.
 * @return - The number of words read from the file.
 */
int read_words(char *word_list[MAX_WORDS], char *file_name)
{
    int number_of_words_read = 0;
    char line[MAX_WORD_LENGTH];
    char *pointer;
    FILE *file = fopen(file_name, "r");

    while (!feof(file))
    {
        pointer = fgets(line, MAX_WORD_LENGTH, file);
        if (pointer != NULL)
        {
            trim_whitespace(line);
            word_list[number_of_words_read] = (char *) malloc(strlen(line) + 1);
            strcpy(word_list[number_of_words_read], line);
            number_of_words_read++;
        }
    }

    fclose(file);
    return number_of_words_read;
}

/**
 * When called, continuously scans in values until all values are zero(except time)
 * This stops words from getting repeatedly entered with one button press
 */
void wait(){
	int time,triangle,circle,cross,square,options,share,r2,l2,up,left,down,right;
	scanVal(&time,&triangle,&circle,&cross,&square,&options,&share,&r2,&l2,&up,&left,&down,&right);
	while(triangle||circle||cross||square||options||share||r2||l2||up||left||down||right){
		scanVal(&time,&triangle,&circle,&cross,&square,&options,&share,&r2,&l2,&up,&left,&down,&right);
	}
}

/**
 * This funtion just scans in all values using pointers
 * Essentially just a shorter way to write scanf throughout the program
 */
void scanVal(int *time,int *triangle,int *circle,int *cross,int *square,int *options,int *share,int *r2,int *l2,int *up,int *left,int *down,int *right){
	int temp;
	scanf("%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d",
			time,triangle,circle,cross,square,&temp,&temp,options,share,r2,l2,&temp,&temp,up,left,down,right);
}

/**
 * Removes all characters in the sentence from the screen(does not change sentence string)
 */
void clearSentence(){
	for(int i=0;i<80;i++){
		mvprintw(16,MAX_WORD_LENGTH+i,"%s"," ");
	}
}

/**
 * Capitalizes first letter or the entire word based on the mode set by the circle button and indicated by caps variable
 */
void capitalize(int caps, char currentWord[MAX_WORD_LENGTH]){
	switch(caps){
		case 1:
			currentWord[0]=toupper(currentWord[0]);
			break;
		case 2:
			for(int i=0;i<MAX_WORD_LENGTH;i++){
				currentWord[i]=toupper(currentWord[i]);
			}
			break;
		default:
			return;
	}
}

/**
 * Prints ^ or ^^ to the screen to indicate which caps mode is active
 */
void printCaps(int caps){
	switch(caps){
		case 1:
			mvaddch(15, MAX_WORD_LENGTH, '^');
			break;
		case 2:
			mvaddch(15, MAX_WORD_LENGTH+1, '^');
			break;
		default:
			mvaddch(15, MAX_WORD_LENGTH, ' ');
			mvaddch(15, MAX_WORD_LENGTH+1, ' ');
			break;
	}
	refresh();
}


