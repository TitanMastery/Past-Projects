package hw1;

/**
 * 
 * @author David Helmick
 *
 */

/**
 * Creates a city object that stores the city's name and the cost of the hostel per night
 */
public class City {
	/**
	 * The cost to mail a postcard from a city is this fraction times the city's hostel cost (rounded to
	 * the nearest integer).
	 */
	public static final double POSTCARD_COST = 0.05;
	/**
	 * stores the city's name
	 */
	private String cityName;
	/**
	 * stores the cost of the hostel per night
	 */
	private int hostelCost;
	
	/**
	 * Constructs a new City with the given name and lodging cost per night.
	 * @param givenCityName the name of the city
	 * @param givenHostelCost the cost of the hostel per night
	 */
	public City(String givenCityName, int givenHostelCost) {
		cityName = givenCityName;
		hostelCost = Math.max(0, givenHostelCost);
	}
	
	/**
	 * Returns this city's name.
	 * @return returns the name of the city
	 */
	public String getCityName() {
		return cityName;
	}
	
	/**
	 * Returns this city's hostel cost per night.
	 * @return returns the cost of the hostel per night
	 */
	public int hostelCost() {
		return hostelCost;
	}
	
	/**
	 * Returns the cost to send a postcard from this city. The value is a percentage of the lodging 
	 * cost specified by the constant POSTCARD_COST, rounded to the nearest integer.
	 * @return returns the cost of a single postcard
	 */
	public int postcardCost() {
		return (int)Math.round(hostelCost * POSTCARD_COST);
	}
	
	/**
	 * Returns the number of nights of hostel stay in this city that a Backpacker could afford with the
	 * given amount of money.
	 * @param moneyAvailable the current funds of the backpacker
	 * @return returns the number of nights that can be afforded in the hostel
	 */
	public int nightsStay(int moneyAvailable) {
		return Math.max(0, (int)(moneyAvailable/hostelCost));
	}
	
	/**
	 * Returns the number of postcards that a Backpacker could afford to send from this city with the
	 * given amount of money.
	 * @param moneyAvailable the current funds of the backpacker
	 * @return returns the number of postcards that can be sent
	 */
	public int numPostcards(int moneyAvailable) {
		return Math.max(0, (int)(moneyAvailable/postcardCost()));
	}
}
