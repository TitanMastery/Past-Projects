package hw1;

/**
 * 
 * @author David Helmick
 *
 */

/**
 * Simulates a backpacker bumming around Europe with limited money, creates a journal of all cities visited
 */
public class Backpacker {
	/**
	 * Proportionality constant when calling home for more money: the amount of money received is
	 * this constant multiplied by the number of postcards the Backpacker has sent home (since the
	 * last time she called home for money).
	 */
	public static final int SYMPATHY_FACTOR = 30;
	/**
	 * stores backpackers current funds
	 */
	private int funds;
	/**
	 * stores the number of nights spent in the train station
	 */
	private int nightsInStation;
	/**
	 * stores the number of postcards sent home since the last time backpacker asked for money
	 */
	private int numPostcards;
	/**
	 * stores the backpacker's current city
	 */
	private City currentCity;
	/**
	 * stores a string containing the cities and number of nights in each city as the backpacker travels
	 */
	private String journal;
	
	/**
	 * Constructs a Backpacker starting out with the given amount of money in the given city. The
	 * journal is initially a string consisting of "cityname(start)", where cityname is the name of the
	 * starting city.
	 * @param initialFunds starting funds for backpacker object
	 * @param initialCity starting city object for backpacker
	 */
	public Backpacker(int initialFunds, City initialCity) {
		funds = initialFunds;
		currentCity = initialCity;
		journal = currentCity.getCityName()+"(start)";
		nightsInStation = 0;
		numPostcards = 0;
	}
	
	/**
	 * Returns the name of the Backpacker's current city.
	 * @return returns the current city of the backpacker
	 */
	public String getCurrentCity() {
		return currentCity.getCityName();
	}
	
	/**
	 * Returns the amount of money the Backpacker currently has.
	 * @return returns the current funds of the backpacker
	 */
	public int getCurrentMoney() {
		return funds;
	}
	
	/**
	 * Returns the Backpacker's journal. The journal is a string of comma-separated values of the
	 * form cityname(number_of_nights) containing the cities visited by the Backpacker, in the order
	 * visited, along with the number of nights spent in each. The first value always has the form
	 * cityname(start) for the starting city. For example, if a Backpacker starts in Paris, spends 5
	 * nights in Rome, and then spends 2 nights in Prague, the journal string would be:
	 * Paris(start),Rome(5),Prague(2).
	 * @return returns backpacker's journal
	 */
	public String getJournal() {
		return journal;
	}
	
	/**
	 * Returns true if Backpacker doesn�t have enough money to send postcard from the current city.
	 * @return returns whether the backpacker is SOL
	 */
	public boolean isSOL() {
		return currentCity.numPostcards(funds) == 0;
	}
	
	/**
	 * Returns the number of nights the Backpacker has spent in a train station when visiting a city
	 * without enough money for hostels.
	 * @return returns number of nights stayed in station
	 */
	public int getNightsInStation() {
		return nightsInStation;
	}
	/**
	 * Simulates a visit by this Backpacker to the given city for the given number of nights. The
	 * Backpacker's money is reduced based on the number of nights of hostel booked. When the
	 * funds are not sufficient for numNights nights of stay in the city, the number of nights spent in
	 * the train station is updated accordingly. The journal is updated by appending a comma, the
	 * city name, and the number of nights in parentheses.
	 * @param c city object that the backpacker is visiting next
	 * @param numNights number of nights stayed in new city
	 */
	public void visit(City c, int numNights) {
		currentCity = c;
		int hostelNights = Math.min(c.nightsStay(funds), numNights);
		nightsInStation += numNights - hostelNights;
		funds -= c.hostelCost() * hostelNights;
		journal += ", " + currentCity.getCityName() + "(" + numNights + ")";
	}
	
	/**
	 * Sends the given number of postcards, if possible, reducing the Backpacker's funds
	 * appropriately and increasing the count of postcards sent. If there is not enough money, sends
	 * as many postcards as possible without allowing the funds to go below zero.
	 * @param howMany how many postcards are sent
	 */
	public void sendPostcardsHome(int howMany) {
		howMany = currentCity.numPostcards(Math.min(funds, howMany * currentCity.postcardCost()));
		numPostcards += howMany;
		funds -= howMany * currentCity.postcardCost();
	}
	
	/**
	 * Increases the Backpacker's funds by an amount equal to SYMPATHY_FACTOR times the
	 * number of postcards sent since the last call to this method, and resets the count of the number
	 * of postcards sent back to zero.
	 */
	public void callHomeForMoney() {
		funds+=SYMPATHY_FACTOR*numPostcards;
		numPostcards = 0;
	}
}
