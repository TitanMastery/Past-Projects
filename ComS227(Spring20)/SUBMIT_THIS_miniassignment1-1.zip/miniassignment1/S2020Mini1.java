package miniassignment1;

import java.util.Scanner;
import java.util.Random;

public class S2020Mini1 {
	public static double squareRoot(double d) {
		double x, x1;
		x = d/2;
		x1 = (x + d / x) / 2;
		while(x!=x1) {
			x = x1;
			x1 = (x + d / x) / 2;
		}
		return x;
	}
	
	public static int findSmallest(String s) {
		int index = 0;
		char lowest = s.charAt(0); 
		char next;
		for(int i = 1; i < s.length(); i++) {
			next = s.charAt(i);
			if(next < lowest) {
				index = i;
				lowest = next;
			}
		}
		return index;
	}
	
	public static int sequenceOfLength(Random r, int limit, int length) {
		int currentSequence = 1;
		int i = 1;
		int currentNum = r.nextInt(limit);
		while(currentSequence < length) {
			int nextNum = r.nextInt(limit);
			if(currentNum + 1 == nextNum) {
				currentSequence++;
			}
			else {
				currentSequence = 1;
			}
			currentNum = nextNum;
			i++;
		}
		return i;
	}
	
	public static int nextIndexOf(String s, String sub, int start) {
		sub = sub.toLowerCase();
		s = s.toLowerCase();
		int index = -1;
		int subLength = sub.length();
		for(int i = start; i < s.length() - (subLength - 1); i++) {
			String test = s.substring(i, i + subLength);
			if(sub.compareTo(test) == 0) {
				index = i;
				break;
			}
		}
		return index;
	}
	
	public static int countDifferences(String s, String t) {
		int count = 0;
		String longer, shorter;
		if(s.length() > t.length()) {
			longer = s;
			shorter = t;
		}
		else {
			longer = t;
			shorter = s;
		}
		count += longer.length() - shorter.length();
		
		for(int i = 0; i < shorter.length(); i++) {
			if(longer.charAt(i)!=shorter.charAt(i)) {
				count++;
			}
		}
		
		return count;
	}
	
	public static boolean isGeometric(String seq) {
		Scanner scan = new Scanner(seq);
		scan.useDelimiter(",");
		int current, next, multiple;
		current = scan.nextInt();
		next = scan.nextInt();
		multiple = next / current;
		current = next;
		
		while(scan.hasNextInt()) {
			next = scan.nextInt();
			if(next / current != multiple) {
				scan.close();
				return false;
			}
			current = next;
		}
		
		scan.close();
		return true;
	}
	
	public static String removeSingles(String s) {
		String answer = "";
		if(s.charAt(0) == s.charAt(1)) {
			answer+=s.charAt(0);
		}
		
		for(int i = 1; i < s.length() - 1; i++) {
			if(s.charAt(i) == s.charAt(i-1) || s.charAt(i) == s.charAt(i+1)) {
				answer+=s.charAt(i);
			}
		}
		
		if(s.charAt(s.length() - 2) == s.charAt(s.length() - 1)) {
			answer+=s.charAt(s.length() - 1);
		}
		
		return answer;
	}
	
	private S2020Mini1() {
		
	}
}