package hw3;

import java.util.Scanner;


import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.io.File;


public class Life {
	private int rows, cols;
	private Cell[][] cells;
	
	/**
	 * Constructs Conways Game of Life give a starting grid (a "seed"), the born rules and the survive rules.  The grid is given as an array of strings as in the following example.
	 * 
	 * 0 0 0 0 0
	 * 0 0 1 0 0
	 * 0 0 1 0 0
	 * 0 0 1 0 0
	 * 0 0 0 0 0
	 * 
	 * @param initConfig an array of Strings encoding the starting grid
	 * @param born an array of integers encoding the rules for a cell being born. 
	 * @param survive an array of integers encoding the rules for a cell surviving. 
	 */
	public Life(String[] initConfig, int[] born, int[] survive) {
		cols = initConfig[0].replace(" ","").length();
		rows = initConfig.length;
		cells = new Cell[rows][cols];
		
		int r = 0;
		int c = 0;
		for(String s:initConfig) {
			Scanner scan = new Scanner(s);
			while(scan.hasNextInt()) {
				boolean alive;
				if(scan.nextInt()==1) {
					alive = true;
				}
				else {
					alive = false;
				}
				cells[r][c] = new Cell(alive, born, survive);
				c++;
			}
			c = 0;
			r++;
			scan.close();
		}
		
		int row = 0;
		int col = 0;
		for(Cell[] cArray1:cells) {
			for(Cell c1:cArray1) {
				int row2 = 0;
				int col2 = 0;
				ArrayList<Cell> neighbors = new ArrayList<Cell>();
				
				for(Cell[] cArray2:cells) {
					for(Cell c2:cArray2) {
						if(((row == row2 - 1 || row == row2 + 1) && col == col2) ||
						   ((col == col2 - 1 || col == col2 + 1) && row == row2) ||
						   ((row == row2 - 1 || row == row2 + 1) && (col == col2 - 1 || col == col2 + 1))) 
						{
							neighbors.add(c2);
						}
						col2++;
					}
					col2 = 0;
					row2++;
				}
				c1.setNeighbors(neighbors);
				col++;
			}
			col = 0;
			row++;
		}
	}
	
	/**
	 * Constructs Conways Game of Life give a starting grid (a "seed"), the born rules and the survive rules.  The grid is given in a file containing a list of strings as in the following example.
	 * 
	 * 0 0 0 0 0
	 * 0 0 1 0 0
	 * 0 0 1 0 0
	 * 0 0 1 0 0
	 * 0 0 0 0 0
	 * 
	 * @param f the File encoding the starting grid
	 * @param born an array of integers encoding the rules for a cell being born. 
	 * @param survive an array of integers encoding the rules for a cell surviving. 
	 * @throws FileNotFoundException
	 */
	public Life(File f, int[] born, int[] survive) throws FileNotFoundException{
		cols = 0;
		rows = 0;
		
		Scanner scan = new Scanner(f);
		Scanner scan2 = new Scanner(scan.nextLine());
		while(scan2.hasNextInt()) {
			scan2.nextInt();
			cols++;
		}
		scan.close();
		
		scan = new Scanner(f);
		while(scan.hasNextLine()) {
			scan.nextLine();
			rows++;
		}
		scan.close();
		
		cells = new Cell[rows][cols];
		
		int r = 0;
		int c = 0;
		scan = new Scanner(f);
		while(scan.hasNextLine()) {
			scan2 = new Scanner(scan.nextLine());
			while(scan2.hasNextInt()) {
				boolean alive;
				if(scan2.nextInt()==1) {
					alive = true;
				}
				else {
					alive = false;
				}
				cells[r][c] = new Cell(alive, born, survive);
				c++;
			}
			c = 0;
			r++;
		}
		scan.close();
		scan2.close();
		
		int row = 0;
		int col = 0;
		for(Cell[] cArray1:cells) {
			for(Cell c1:cArray1) {
				int row2 = 0;
				int col2 = 0;
				ArrayList<Cell> neighbors = new ArrayList<Cell>();
				
				for(Cell[] cArray2:cells) {
					for(Cell c2:cArray2) {
						if(((row == row2 - 1 || row == row2 + 1) && col == col2) ||
						   ((col == col2 - 1 || col == col2 + 1) && row == row2) ||
						   ((row == row2 - 1 || row == row2 + 1) && (col == col2 - 1 || col == col2 + 1))) 
						{
							neighbors.add(c2);
						}
						col2++;
					}
					col2 = 0;
					row2++;
				}
				c1.setNeighbors(neighbors);
				col++;
			}
			col = 0;
			row++;
		}
	}
	
	/**
	 * Returns cell at specified position
	 * @param row index of the row 
	 * @param col index of the column
	 * @return Cell at position (row, col)
	 */
	public Cell getCell(int row, int col) {
		return cells[row][col];
	}
	
	/**
	 * Returns the number of rows in the Game of Life
	 * @return number of rows in grid
	 */
	public int getRows() {
		return rows;
	}
	
	
	/**
	 * Returns the number of columns in the Game of Life
	 * @return number of columns in grid
	 */
	public int getColumns() {
		return cols;
	}
	
	/**
	 * Performs one generation of the game
	 * 
	 */
	public void nextGeneration() {
		for(Cell[] cArray:cells) {
			for(Cell c:cArray) {
				c.setIsAliveNextGeneration();
			}
		}
		for(Cell[] cArray:cells) {
			for(Cell c:cArray) {
				c.nextGeneration();
			}
		}
	}
	
		


	/**
	 * Returns a String representation of the game. Returns the String representation of each element of the game in a grid.
	 * 
	 * @return a string representing the current state of the game.
	 */
	public String toString() {
		String grid = "";
		
		for(Cell[] cArray:cells) {
			for(Cell c:cArray) {
				if(c.isAlive()) {
					grid += "1 ";
				}
				else {
					grid += "0 ";
				}
			}
			grid = grid.substring(0,grid.length()-1) + '\n';
		}
		
		return grid;
		
	}
	
	

	
}
