package hw3;

import java.util.ArrayList;

public class Cell {

	private boolean alive,aliveNextGeneration;
	private int[] born, survive;
	private ArrayList<Cell> neighbors;
	
	/**
	 * Constructs a new cell in a Game of Life
	 * @param alive the initial state of the cell
	 * @param b an array of integers encoding the born rules for the cell
	 * @param s an array of integers encoding the survive rules for the cell
	 */
	public Cell(boolean alive, int[] b, int[] s) {
		this.alive = alive;
		born = b;
		survive = s;
	}
	
	/**
	 * Returns the boolean value of whether the cell is dead or alive. 
	 * 
	 * @return the boolean value of whether the cell is dead or alive.
	 */
	public boolean isAlive() {
		return alive;
	}
	
	/**
	 * Returns the boolean value of whether the cell is dead or alive in the next generation.
	 * 
	 * @return the boolean value of whether the cell is dead or alive in the next generation.
	 */
	public boolean isAliveAfterNextGeneration() {
		return aliveNextGeneration;
	}
	
	/**
	 * Sets the status of the cell (dead or alive) in the next generation. The status is determined by the born and alive rules.
	 */
	public void setIsAliveNextGeneration() {
		int aliveNeighbors = getNumAliveNeighbors();
		boolean aliveNext = false;
		if(alive) {
			for(int s:survive) {
				if(aliveNeighbors == s) {
					aliveNext = true;
					break;
				}
			}
		}
		else {
			for(int b:born) {
				if(aliveNeighbors == b) {
					aliveNext = true;
					break;
				}
			}
		}
		
		
		aliveNextGeneration = aliveNext;
	}
	
	/**
	 * Sets the neighbors of the cell. Note that the cell is not neighbors with itself.
	 * 
	 *  @param ArrayList of Cells of the neighboring cells.
	 * 
	 */
	public void setNeighbors(ArrayList<Cell> n) {
		neighbors = new ArrayList<Cell>();  
		neighbors.addAll(n);
	}
	
	/**
	 * Gets the neighbors of the cell. Note that the cell is not neighbors with itself.
	 * 
	 *  @return number of the neighboring cells.
	 * 
	 */
	public int getNumNeighbors() {
		  return neighbors.size();
	}
	
	/**
	 * Gets the number of neighbors which are alive.
	 * 
	 * @return number of neighboring cells which are alive
	 */
	public int getNumAliveNeighbors() {
		int i = 0;
		
		for(Cell c:neighbors) {
			if(c.isAlive()) {
				i++;
			}
		}
		
		return i;
	}
	
	/**
	 * Sets the current status of the cell equal to the status of the cell after one generation of the game. 
	 */
	public void nextGeneration() {
		alive = aliveNextGeneration;
	}
	
	/**
	 * Returns the survive rule of the cell encoded in an array.
	 * 
	 * @return a copy of the born rule this cell is initialized with.
	 */
	public int[] getBornRule() {
		return born;
	}
	
	/**
	 * Returns the survive rule of the cell encoded in an array.
	 * 
	 * @return a copy of the survive rule this cell is initialized with.
	 */
	public int[] getSurviveRule() {
		return survive;
	}
	
	/**
	 * Returns a String representation of the cell. Returns "0" if the cell is dead or "1" if the cell is alive.
	 * 
	 * @return a string representing the current state of the cell.
	 */
	public String toString() {
		if(alive) {
			return "1";
		}
		else {
			return "0";
		}
	}
	
}

