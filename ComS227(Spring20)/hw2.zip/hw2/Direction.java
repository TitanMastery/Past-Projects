package hw2;
/**
 * Possible status of a maze cell.
 */
  public enum Direction {NORTH, SOUTH, WEST, EAST, DOWN};
