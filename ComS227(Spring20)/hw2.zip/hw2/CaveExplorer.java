package hw2;

import java.util.Random;
import static hw2.Status.*;
import static hw2.Direction.*;

/**
 *
 * A Cave Explorer
 * 
 */
public class CaveExplorer {
	/**
	 * A constant that represents the maximum energy that a player can have at one time, initialized to 100
	 */
	public static final int MAX_ENERGY = 100;
	private Location current;
	private int timeClock, energyLevel, foodItemsLeft, matchesLeft;
	private Map caveMap;
	private String resources;
	
	/**
	 * Create a new CaveExplorer and place him/her at the given initial location. A new player's time clock is at 100, his/her energy is at MAX_ENERGY, carrying one food item and 10 matches. Additionally, on the map mark the Status of the initial location at as PLAYER.
	 * @param map a given map
	 * @param initial the initial location of the player.
	 */
	public CaveExplorer(Map map, Location initial) {
		caveMap = map;
		current = initial;
		timeClock = 100;
		energyLevel = MAX_ENERGY;
		foodItemsLeft = 1;
		matchesLeft = 10;
		resources = "";
		caveMap.mark(current, PlAYER);
	}
	
	/**
	 * Create a new CaveExplorer using the given Random generator. A new player's time clock is at 100, his/her energy is at MAX_ENERGY, carrying one food item and 10 matches. The initial location must be picked using the getRandomOpenLocation method of the Map class and the given Random generator. Additionally, on the map mark the Status of the cell where the player is at as PLAYER.
	 * @param map a given map
	 * @param generator a given Random generator.
	 */
	public CaveExplorer(Map map, Random generator) {
		caveMap = map;
		current = caveMap.getRandomOpenLocation(generator);
		timeClock = 100;
		energyLevel = MAX_ENERGY;
		foodItemsLeft = 1;
		matchesLeft = 10;
		resources = "";
		caveMap.mark(current, PlAYER);
	}

	/**
	 * This constructor is the same as the other constructors except that the initial clock time, energy, number of food items, number of matches, and initial location are all set by the user.
	 * @param map map
	 * @param clock time clock
	 * @param energy initial energy level
	 * @param foodItems number of food items
	 * @param matches number of matches
	 * @param initial initial location
	 */
	public CaveExplorer(Map map, int clock, int energy, int foodItems, int matches, Location initial) {
		caveMap = map;
		current = initial;
		timeClock = clock;
		energyLevel = energy;
		foodItemsLeft = foodItems;
		matchesLeft = matches;
		resources = "";
		caveMap.mark(current, PlAYER);
	}
	
	/**
	 * this method returns a list of resources that player currently has. This action consumes one unit of energy and the clock goes down by 1.
	 * @return a String representation of resource available.
	 */
	public String checkResource() {
		energyLevel--;
		timeClock--;
		return resources;
	}
	
	/**
	 * Eat consumes one food item. It increases the energy by 10 (but not to surpass the MAX_ENERGY). the clock goes down by 1 each time this method is called, even when there is no food item.
	 */
	public void eat() {
		if(foodItemsLeft>0) {
			energyLevel = Math.min(MAX_ENERGY, energyLevel + 10);
			foodItemsLeft--;
		}
		timeClock--;
	}
	
	/**
	 * return the clock time left
	 * @return time left
	 */
	public int getClock() {
		return timeClock;
	}
	
	/**
	 * return the current energy level of the player
	 * @return energy
	 */
	public int getEnergy() {
		return energyLevel;
	}
	
	/**
	 * return the number of foodItem left
	 * @return the number of foodItem left
	 */
	public int getFoodItems() {
		return foodItemsLeft;
	}
	
	/**
	 * return the current location of the player
	 * @return location
	 */
	public Location getLocation() {
		return current;
	}
	
	/**
	 * return the map.
	 * @return map
	 */
	public Map getMap() {
		return caveMap;
	}
	
	/**
	 * return the number of matches left
	 * @return the number of matches left
	 */
	public int getMatches() {
		return matchesLeft;
	}
	
	/**
	 * return true if the player has the life jacket, false otherwise.
	 * @return true if having the jacket.
	 */
	public boolean hasJacket() {
		return resources.contains(JACKET.toString());
	}
	
	/**
	 * return true if the player has the key, which is needed to open the door.
	 * @return true if having the key, false otherwise.
	 */
	public boolean hasKey() {
		return resources.contains(KEY.toString());
	}
	
	/**
	 * return true if the player reaches the cave exit.
	 * @return true if the player reaches the exit.
	 */
	public boolean hasWon() {
		return caveMap.getCellStatus(current) == EXIT;
	}
	
	/**
	 * the player is still in the game if the clock has not run out AND he still has energy.
	 * @return if the player is still in the game
	 */
	public boolean isAlive() {
		return (timeClock > 0 && energyLevel > 0);
	}
	
	/**
	 * jump in the given direction. The explorer will jump 3 steps in the given direction if energy is 75 or above, 2 steps if energy is 50 to 74, and 1 step if energy is less than 50, which moves him/her the same distance as a move() action does, but consumes more energy. The player cannot jump over WALL nor DOOR. The player can jump and land on a DOOR only if he/she has the key. Each jump consumes 25 units of energy even if it fails. Clock goes down by 1. If the jump is successful, the Status of the current cell on the map is changed to "MARK" if it was PLAYER, and the Status of the new location is changed to "PLAYER" if it was OPEN or MARK.
	 * @param d direction to jump
	 * @return true if the jump is successful or false otherwise
	 */
	public boolean jump(Direction d) {
		int spaces;
		
		if(energyLevel >= 75) {
			spaces = 3;
		}
		else if(energyLevel >= 50) {
			spaces = 2;
		}
		else {
			spaces = 1;
		}
		
		energyLevel = Math.max(energyLevel - 25 * spaces, 0);
		timeClock--;
		Location progress = current;
		Status progressStatus;
		
		//this would be easier with a loop, but I didn't want to lose points so I used conditionals and lots of repetition
		if(spaces==3) {
			progress = directionToLocation(d, progress);
			progressStatus = caveMap.getCellStatus(progress);
			if(progressStatus == WALL || progressStatus == DOOR && !hasKey()) {
				return false;
			}
			progress = directionToLocation(d, progress);
			progressStatus = caveMap.getCellStatus(progress);
			if(progressStatus == WALL || progressStatus == DOOR && !hasKey()) {
				return false;
			}
			progress = directionToLocation(d, progress);
			progressStatus = caveMap.getCellStatus(progress);
			if(progressStatus == WALL || progressStatus == DOOR && !hasKey()) {
				return false;
			}
		}
		else if(spaces==2) {
			progress = directionToLocation(d, progress);
			progressStatus = caveMap.getCellStatus(progress);
			if(progressStatus == WALL || progressStatus == DOOR && !hasKey()) {
				return false;
			}
			progress = directionToLocation(d, progress);
			progressStatus = caveMap.getCellStatus(progress);
			if(progressStatus == WALL || progressStatus == DOOR && !hasKey()) {
				return false;
			}
		}
		else if(spaces==1) {
			progress = directionToLocation(d, progress);
			progressStatus = caveMap.getCellStatus(progress);
			if(progressStatus == WALL || progressStatus == DOOR && !hasKey()) {
				return false;
			}
		}
		
		if(caveMap.getCellStatus(current) == PlAYER) {
			caveMap.mark(current, MARK);
		}
		current = progress;
		if(caveMap.getCellStatus(current) == MARK || caveMap.getCellStatus(current) == OPEN) {
			caveMap.mark(current, PlAYER);
		}
		return true;
	}
	
	/**
	 * Look towards the given direction. If no match is left, return "DARKNESS", otherwise return the status of the neighboring cell in the given direction. Use Status' toString method to get a String representation of a Status. The action consumes one match (if any) and one energy. The clock goes down by 1.
	 * @param d a direction
	 * @return what is visible in the given direction.
	 */
	public String look(Direction d) {
		timeClock--;
		if (matchesLeft == 0) {
			return "DARKNESS";
		}
		else {
			matchesLeft--;
			energyLevel--;
			return caveMap.getCellStatus(directionToLocation(d,current)).toString();
		}
	}
	
	/**
	 * move one step towards the given direction. The move fails if the next location is WALL, or it is a DOOR and the player does not have the key. In each move attempt (even if it fails), one unit of energy is consumed, the clock runs down by 1. If the move is successful, the Status of the current cell is changed to "MARK" on the map if it was PLAYER, and the Status of the new location is changed to "PLAYER" if it was OPEN or MARK. The player loses all his/her energy if the new location is a PIT or WATER (without a JACKET). If the new location is WATER, the player loses half of his food items and his matches (using integer division), whether he has life JACKET or not.
	 * @param d direction
	 * @return true if the player can make the move.
	 */
	public boolean move(Direction d) {
		energyLevel--;
		timeClock--;
		Location next = directionToLocation(d, current);
		Status nextStatus = caveMap.getCellStatus(next);
		if(nextStatus == WALL || nextStatus == DOOR && !hasKey()) {
			return false;
		}
		else if(nextStatus == OPEN || nextStatus == MARK){
			caveMap.mark(next, PlAYER);
		}
		else if(nextStatus == WATER){
			foodItemsLeft /= 2;
			matchesLeft /= 2;
			if(!hasJacket()) {
				energyLevel = 0;
			}
		}
		else if(nextStatus == PIT){
			energyLevel = 0;
		}
		caveMap.mark(current, MARK);
		current = next;
		return true;
	}
	
	/**
	 * If there is a key, or jacket, or food, or match on the current location, calling this method will pick up the item (20 of them, in the case of matches), and the Status of the current cell on the map is changed to "PLAYER", otherwise do nothing. The player's clock and energy is not affected by this action.
	 */
	public void pickUp() {
		Status currentStatus = caveMap.getCellStatus(current);
		if(currentStatus == KEY || currentStatus == JACKET) {
			caveMap.mark(current, PlAYER);
			resources += currentStatus.toString();
		}
		else if(currentStatus == MATCH) {
			caveMap.mark(current, PlAYER);
			matchesLeft += 20;
		}
		else if(currentStatus == FOOD) {
			caveMap.mark(current, PlAYER);
			foodItemsLeft++;
		}
	}
	
	/**
	 * Taking a rest increases the energy by 10 (but not to surpass the MAX_ENERGY). The clock goes down by 10 each time this action is taken.
	 */
	public void rest() {
		timeClock -= 10;
		energyLevel = Math.min(MAX_ENERGY, energyLevel + 10);
	}
	
	/**
	 * Takes the current location and a direction and then translates the location in the direction by 1
	 * @param d a direction
	 * @param c current location
	 * @return new location in direction of d
	 */
	private Location directionToLocation(Direction d, Location c) {
		Location newLocation = new Location(c);
		if(d==NORTH) {
			newLocation.translate(-1, 0);
		}
		else if(d==SOUTH) {
			newLocation.translate(1, 0);
		}
		else if(d==WEST) {
			newLocation.translate(0, -1);
		}
		else if(d==EAST) {
			newLocation.translate(0, 1);
		}
		return newLocation;
	}
}