package hw2;
/**
 * Possible status of a cave cell.
 */
  
  public enum Status {WALL, PlAYER, OPEN, MARK, FOOD, KEY, DOOR, EXIT, PIT, MATCH, WATER, JACKET};