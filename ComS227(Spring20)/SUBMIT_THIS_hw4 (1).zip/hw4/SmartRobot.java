package hw4;
/**
 * Class to represent smart robots.  Smart robots will not collide with
 * rubble or other robots (however, other robots can collide with smart
 * robots.
 */
public class SmartRobot extends Robot {

  /**
   * Stringifies a smart robot
   *
   * @return The stringified robot
   */
  @Override
  public String toString()
  {
    return "S";
  }

  /**
   * Constructs a new smart robot at position (x, y)
   *
   * @param x The x position of the robot
   * @param y The y position of the robot
   */
  public SmartRobot(int x, int y)
  {
    super(x, y);
  }

  /**
   * TODO: Smart robots move toward the PC is at least one dimension, both if
   * possible, but only if there exists a move which doesn't result in a
   * collision.  A smart robot will never collide with obstructions or other
   * robots.  It can get stuck behind an obstruction (or, optionally, you can
   * implement some more intelligent pathfinding around obstructions, but that
   * is harder to code, and make an already very hard game harder, as well).
   *
   * @param t The tableau
   * @return The new position
   */
  public Pair moveTo(Tableau t) {
	  PlayerCharacter p = t.getPC();
	  int px = p.getX();
	  int py = p.getY();
	  
	  int rx = this.getX();
	  int ry = this.getY();
	  
	  if(px>rx) {
		  rx++;
	  }
	  else if(px<rx) {
		  rx--;
	  }
	  
	  if(py>ry) {
		  ry++;
	  }
	  else if(py<ry) {
		  ry--;
	  }
	  
	  if(t.getCell(rx, ry) == null || t.getCell(rx, ry).toString().equals("@")) {
		  return new Pair(rx,ry);
	  }
	  else {
		  return new Pair(this.getX(),this.getY());
	  }
	  
  }
}
