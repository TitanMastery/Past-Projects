package edu.iastate.cs228.hw3;

import java.util.AbstractSequentialList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * Implementation of the list interface based on linked nodes
 * that store multiple items per node.  Rules for adding and removing
 * elements ensure that each node (except possibly the last one)
 * is at least half full.
 */
@SuppressWarnings("unused")
public class StoutList<E extends Comparable<? super E>> extends AbstractSequentialList<E>
{
  /**
   * Default number of elements that may be stored in each node.
   */
  private static final int DEFAULT_NODESIZE = 4;
  
  /**
   * Number of elements that can be stored in each node.
   */
  private final int nodeSize;
  
  /**
   * Dummy node for head.  It should be private but set to public here only  
   * for grading purpose.  In practice, you should always make the head of a 
   * linked list a private instance variable.  
   */
  public Node head;
  
  /**
   * Dummy node for tail.
   */
  private Node tail;
  
  /**
   * Number of elements in the list.
   */
  private int size;
  
  /**
   * Constructs an empty list with the default node size.
   */
  public StoutList()
  {
    this(DEFAULT_NODESIZE);
  }

  /**
   * Constructs an empty list with the given node size.
   * @param nodeSize number of elements that may be stored in each node, must be 
   *   an even number
   */
  public StoutList(int nodeSize)
  {
    if (nodeSize <= 0 || nodeSize % 2 != 0) throw new IllegalArgumentException();
    
    // dummy nodes
    head = new Node();
    tail = new Node();
    head.next = tail;
    tail.previous = head;
    this.nodeSize = nodeSize;
  }
  
  /**
   * Constructor for grading only.  Fully implemented. 
   * @param head
   * @param tail
   * @param nodeSize
   * @param size
   */
  public StoutList(Node head, Node tail, int nodeSize, int size)
  {
	  this.head = head; 
	  this.tail = tail; 
	  this.nodeSize = nodeSize; 
	  this.size = size; 
  }

  //returns the number of elements in the list
  @Override
  public int size()
  {
    return size;
  }
  
  //adds an item to the list without using an iterator
  @Override
  public boolean add(E item)
  {
	  Node n = new Node();
	  size++;
	  if(head.next==tail) {
    	n.addItem(item);
    	head.next = n;
    	n.previous=head;
    	n.next=tail;
    	tail.previous=n;
    	return true;
    }
    else if(tail.previous.count!=nodeSize) {
    	tail.previous.addItem(item);
    	return true;
    }
    else if(tail.previous.count==nodeSize) {
    	n.addItem(item);
    	tail.previous.next = n;
    	n.previous=tail.previous;
    	n.next=tail;
    	tail.previous=n;
    	return true;
    }
	size--;
    return false;
  }

  //adds an item to the list at the given position without the use of an iterator
  @Override
  public void add(int pos, E item)
  {
    size++;
	Node index = head.next;
    int count = index.count;
    while(count<pos) {
    	index = index.next;
    	count+= index.count;
    }
    if(count==pos&&index.count!=nodeSize) {
    	index.addItem(item);
    }
    else if(count!=pos&&index.count!=nodeSize) {
    	index.addItem(count-pos, item);
    }
    else if(index.count==nodeSize) {
    	Node n = new Node();
    	n.previous = index;
    	n.next = index.next;
    	index.next = n;
    	n.next.previous = n;
    	
    	int j = 0;
    	for(int i=nodeSize/2;i<=nodeSize;i++) {
    		n.addItem(j, index.data[i]);
    		j++;
    	}
    	while(j>=0) {
    		index.removeItem(nodeSize/2);
    		j--;
    	}
    	
    	if(count-pos>=nodeSize/2) {
    		n.addItem(count-pos-(nodeSize/2), item);
    	}
    	else if(count-pos<nodeSize/2) {
    		index.addItem(count-pos, item);
    	}
    }
  }

  //removes an item from the list at the given position without the use of an iterator
  @Override
  public E remove(int pos)
  {
    size--;
    Node index = head.next;
    int count = index.count;
    while(count<pos) {
    	index = index.next;
    	count+= index.count;
    }
    
    E removed = null;
    if(index.count==1&&index.next==tail) {
    	index.previous.next=tail;
    	tail.previous=index.previous;
    	removed=index.data[count-pos];
    }
    else if(index.next==tail||
    		index.count>nodeSize/2) {
    	removed=index.data[count-pos];
    	index.removeItem(count-pos);
    }
    else if(index.count<=nodeSize/2) {
    	removed=index.data[count-pos];
		index.removeItem(count-pos);
		
    	if(index.next.count>nodeSize/2) {
    		index.addItem(index.next.data[0]);
    		index.next.removeItem(0);
    	}
    	else if(index.next.count<=nodeSize/2) {
    		for(int i=0;i<index.next.count;i++) {
    			index.addItem(index.next.data[i]);
    		}
    		index.next=index.next.next;
    		index.next.previous=index;
    	}
    }
    return removed;
  }

  /**
   * Sort all elements in the stout list in the NON-DECREASING order. You may do the following. 
   * Traverse the list and copy its elements into an array, deleting every visited node along 
   * the way.  Then, sort the array by calling the insertionSort() method.  (Note that sorting 
   * efficiency is not a concern for this project.)  Finally, copy all elements from the array 
   * back to the stout list, creating new nodes for storage. After sorting, all nodes but 
   * (possibly) the last one must be full of elements.  
   *  
   * Comparator<E> must have been implemented for calling insertionSort().    
   */
  public void sort()
  {
	  E[] elements = listToArray();
	  Comparator<E> compare = new SortComparator();
	  insertionSort(elements,compare);
  }
  
  /**
   * Sort all elements in the stout list in the NON-INCREASING order. Call the bubbleSort()
   * method.  After sorting, all but (possibly) the last nodes must be filled with elements.  
   *  
   * Comparable<? super E> must be implemented for calling bubbleSort(). 
   */
  public void sortReverse() 
  {
	  E[] elements = listToArray();
	  bubbleSort(elements);
  }
  
  //turns the current list into an E[]
  private E[] listToArray() {
	  @SuppressWarnings("unchecked")
	  E[] elements = (E[]) new Comparable[size];
	  int i = 0;
	  Node indexNode = head;
	  
	  while(i!=size) {
		  indexNode = indexNode.next;
		  if(indexNode.count>0) {
			  for(int j=0;j<indexNode.count;j++) {
				  elements[i] = indexNode.data[j];
				  i++;
			  }
		  }
	  }
	  return elements;
  }
  
  //creates a list based off the provided array
  private void arrayToList(E[] elements) {
	  Node indexNode = new Node();
	  head.next = indexNode;
	  indexNode.previous = head;
	  
	  for(int i=0;i<elements.length;i++) {
		  if(indexNode.count==nodeSize) {
			  Node n = new Node();
			  n.previous = indexNode;
			  indexNode.next = n;
			  indexNode = n;
		  }
		  indexNode.addItem(elements[i]);
	  }
	  
	  tail.previous = indexNode;
	  indexNode.next = tail;
  }
  
  //returns new list iterator
  @Override
  public Iterator<E> iterator()
  {
    return new StoutListIterator();
  }

  //returns new list iterator
  @Override
  public ListIterator<E> listIterator()
  {
    return new StoutListIterator();
  }

  //returns new list iterator with the cursor at the index provided
  @Override
  public ListIterator<E> listIterator(int index)
  {
    return new StoutListIterator(index);
  }
  
  /**
   * Returns a string representation of this list showing
   * the internal structure of the nodes.
   */
  public String toStringInternal()
  {
    return toStringInternal(null);
  }

  /**
   * Returns a string representation of this list showing the internal
   * structure of the nodes and the position of the iterator.
   *
   * @param iter
   *            an iterator for this list
   */
  public String toStringInternal(ListIterator<E> iter) 
  {
      int count = 0;
      int position = -1;
      if (iter != null) {
          position = iter.nextIndex();
      }

      StringBuilder sb = new StringBuilder();
      sb.append('[');
      Node current = head.next;
      while (current != tail) {
          sb.append('(');
          E data = current.data[0];
          if (data == null) {
              sb.append("-");
          } else {
              if (position == count) {
                  sb.append("| ");
                  position = -1;
              }
              sb.append(data.toString());
              ++count;
          }

          for (int i = 1; i < nodeSize; ++i) {
             sb.append(", ");
              data = current.data[i];
              if (data == null) {
                  sb.append("-");
              } else {
                  if (position == count) {
                      sb.append("| ");
                      position = -1;
                  }
                  sb.append(data.toString());
                  ++count;

                  // iterator at end
                  if (position == size && count == size) {
                      sb.append(" |");
                      position = -1;
                  }
             }
          }
          sb.append(')');
          current = current.next;
          if (current != tail)
              sb.append(", ");
      }
      sb.append("]");
      return sb.toString();
  }


  /**
   * Node type for this list.  Each node holds a maximum
   * of nodeSize elements in an array.  Empty slots
   * are null.
   */
  private class Node
  {
    /**
     * Array of actual data elements.
     */
    // Unchecked warning unavoidable.
    @SuppressWarnings("unchecked")
	public E[] data = (E[]) new Comparable[nodeSize];
    
    /**
     * Link to next node.
     */
    public Node next;
    
    /**
     * Link to previous node;
     */
    public Node previous;
    
    /**
     * Index of the next available offset in this node, also 
     * equal to the number of elements in this node.
     */
    public int count;

    /**
     * Adds an item to this node at the first available offset.
     * Precondition: count < nodeSize
     * @param item element to be added
     */
    void addItem(E item)
    {
      if (count >= nodeSize)
      {
        return;
      }
      data[count++] = item;
      //useful for debugging
      //      System.out.println("Added " + item.toString() + " at index " + count + " to node "  + Arrays.toString(data));
    }
  
    /**
     * Adds an item to this node at the indicated offset, shifting
     * elements to the right as necessary.
     * 
     * Precondition: count < nodeSize
     * @param offset array index at which to put the new element
     * @param item element to be added
     */
    void addItem(int offset, E item)
    {
      if (count >= nodeSize)
      {
    	  return;
      }
      for (int i = count - 1; i >= offset; --i)
      {
        data[i + 1] = data[i];
      }
      ++count;
      data[offset] = item;
      //useful for debugging 
//      System.out.println("Added " + item.toString() + " at index " + offset + " to node: "  + Arrays.toString(data));
    }

    /**
     * Deletes an element from this node at the indicated offset, 
     * shifting elements left as necessary.
     * Precondition: 0 <= offset < count
     * @param offset
     */
    void removeItem(int offset)
    {
	E item = data[offset];
      for (int i = offset + 1; i < nodeSize; ++i)
      {
        data[i - 1] = data[i];
      }
      data[count - 1] = null;
      --count;
    }    
  }
 
  //class to control iterating through the stoutlist
  private class StoutListIterator implements ListIterator<E>
  {
	int cursor,off;
	Node current;
	E item;
	
    /**
     * Default constructor 
     */
    public StoutListIterator()
    {
    	cursor = 0; 
    	off=0;
    	current = head;
    	item = null;
    }

    /**
     * Constructor finds node at a given position.
     * @param pos
     */
    public StoutListIterator(int pos)
    {
    	cursor = pos; 
    	current = head.next;
        int count = current.count;
        while(count<pos) {
        	current = current.next;
        	count+= current.count;
        }
        off=count-pos;
        item=current.data[off];
    }

    //checks the list to see if there is an item after the cursor
    @Override
    public boolean hasNext()
    {
    	if(size>cursor) {
    		return true;
    	} 
    	return false;
    }

    //moves to the next item in the list
    @Override
    public E next()
    {
    	if(hasNext()) {
    		cursor++;
    		if(current.data[off+1]!=null) {
    			off++;
    		}
    		else {
    			current=current.next;
    			off=0;
    		}
			item=current.data[off];
			return item;
    	}
    	return null;
    }
    
    //removes the current element from the list
    @Override
    public void remove()
    {
    	size--;
    	if(current.next==tail&&current.count==1) {
    		current.previous.next=tail;
    		tail.previous=current.previous;
    		current=current.previous;
    		cursor--;
    		off=current.count;
    		if(size>0) {
    			item=current.data[off];
    		}
    		else {
    			item=null;
    		}
    	}
    	else if(current.count>nodeSize/2||
    			(current.next==tail&&current.count>1)) {
    		current.removeItem(off);
    		if(off>0) {
    			off--;
    			cursor--;
    		}
			item=current.data[off];
    	}
    	else if(current.count<=nodeSize/2) {
    		current.removeItem(off);
    		
        	if(current.next.count>nodeSize/2) {
        		current.addItem(current.next.data[0]);
        		current.next.removeItem(0);
        	}
        	else if(current.next.count<=nodeSize/2) {
        		for(int i=0;i<current.next.count;i++) {
        			current.addItem(current.next.data[i]);
        		}
        		current.next=current.next.next;
        		current.next.previous=current;
        	}
        	item=current.data[off];
        }
    }

    //checks to see if there are any items before the cursor
	@Override
	public boolean hasPrevious() {
		if(cursor>0) {
    		return true;
    	} 
    	return false;
	}

	//moves the cursor back an element
	@Override
	public E previous() {
		if(hasPrevious()) {
    		cursor--;
    		if(off!=0) {
    			off--;
    		}
    		else {
    			current=current.previous;
    			off=current.count-1;
    		}
    		item=current.data[off];
			return item;
    	}
    	return null;
	}

	//returns the next cursor index
	@Override
	public int nextIndex() {
		return cursor+1;
	}

	//returns the previous cursor index
	@Override
	public int previousIndex() {
		return cursor-1;
	}

	//sets the current element to the new element
	@Override
	public void set(E e) {
		item = e;
		current.data[off]=item;
	}

	//adds a new element to the list, shifting as needed
	@Override
	public void add(E e) {
		size++;
		if(head.next==tail) {
	    	Node n = new Node();
			n.addItem(e);
	    	head.next = n;
	    	n.previous=head;
	    	n.next=tail;
	    	tail.previous=n;
	    	current=n;
	    	cursor++;
	    	item=e;
	    }
		else if(current.count<nodeSize) {
			current.addItem(off,e);
			item=e;
		}
		else if(size==cursor&&current.count==nodeSize) {
			Node n = new Node();
			n.addItem(e);
	    	current.next = n;
	    	n.previous=current;
	    	n.next=tail;
	    	tail.previous=n;
	    	current=n;
	    	cursor++;
	    	off=0;
	    	item=e;
		}
		else if(current.count==nodeSize) {
			Node n = new Node();
	    	n.previous = current;
	    	n.next = current.next;
	    	current.next = n;
	    	n.next.previous = n;
	    	
	    	int j = 0;
	    	for(int i=nodeSize/2;i<=nodeSize;i++) {
	    		n.addItem(j, current.data[i]);
	    		j++;
	    	}
	    	while(j>=0) {
	    		current.removeItem(nodeSize/2);
	    		j--;
	    	}
	    	
	    	if(off>=nodeSize/2) {
	    		current=n;
	    		off=off-(nodeSize/2);
	    		n.addItem(off, e);
	    	}
	    	else if(off<nodeSize/2) {
	    		current.addItem(off, e);
	    	}
	    	item=e;
		}
	}
  }
  

  /**
   * Sort an array arr[] using the insertion sort algorithm in the NON-DECREASING order. 
   * @param arr   array storing elements from the list 
   * @param comp  comparator used in sorting 
   */
  private void insertionSort(E[] arr, Comparator<? super E> comp)
  {
	  E temp = null;
	  
	  for(int i=1;i<arr.length;i++) {
		  for(int j=i;j>0;j--) {
			  if(arr[j].compareTo(arr[j-1])<0) {
				  temp=arr[j-1];
				  arr[j-1]=arr[j];
				  arr[j]=temp;
			  }
		  }
	  }
	  
	  arrayToList(arr);
  }
  
  /**
   * Sort arr[] using the bubble sort algorithm in the NON-INCREASING order. For a 
   * description of bubble sort please refer to Section 6.1 in the project description. 
   * You must use the compareTo() method from an implementation of the Comparable 
   * interface by the class E or ? super E. 
   * @param arr  array holding elements from the list
   */
  private void bubbleSort(E[] arr)
  {
	  E temp = null;
	  
	  for(int i=arr.length;i>0;i--) {
		  for(int j=0;j<i-1;j++) {
			  if(arr[j].compareTo(arr[j+1])<0) {
				  temp=arr[j+1];
				  arr[j+1]=arr[j];
				  arr[j]=temp;
			  }
		  }
	  }
	  
	  arrayToList(arr);
  }
 
  //comparator to be used for sorting methods
  private class SortComparator implements Comparator<E>{

	@Override
	public int compare(E o1, E o2) {
		return o1.compareTo(o2);
	}
	  
  }
}