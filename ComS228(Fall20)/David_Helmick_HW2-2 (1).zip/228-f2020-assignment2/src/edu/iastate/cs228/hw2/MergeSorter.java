package edu.iastate.cs228.hw2;


import java.util.Comparator;


/**
 * An implementation of {@link Sorter} that performs merge sort
 * to sort the list.
 * 
 * @author David Helmick
 */
public class MergeSorter extends Sorter
{
  @Override
  public void sort(WordList toSort, Comparator<String> comp) throws NullPointerException{
    mergeSortRec(toSort,comp,0,toSort.length()-1);
  }

  private void mergeSortRec(WordList list, Comparator<String> comp, int start, int end)
  {
    if(start==end) {
    	return;
    }
    
    int mid = end-((end-start)/2);
    
    mergeSortRec(list,comp,start,mid-1);
    mergeSortRec(list,comp,mid,end);
    
    String[] words=new String[end+1-start];
    
    int i = 0;
    int j = start;
    int k = mid;
    while(j<mid && k<=end) {
    	if(comp.compare(list.get(j), list.get(k))<1) {
    		words[i] = list.get(j);
    		i++;
    		j++;
    	}
    	else {
    		words[i] = list.get(k);
    		i++;
    		k++;
    	}
    }
    if(j==mid) {
    	while(k<=end) {
    		words[i] = list.get(k);
    		i++;
    		k++;
    	}
    }
    else {
    	while(j<mid) {
    		words[i] = list.get(j);
    		i++;
    		j++;
    	}
    }
    int p = 0;
    for(int x = start; x<=end;x++) {
    	list.set(x,words[p]);
    	p++;
    }
  }
}
