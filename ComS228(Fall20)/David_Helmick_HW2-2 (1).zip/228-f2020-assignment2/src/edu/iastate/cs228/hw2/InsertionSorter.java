package edu.iastate.cs228.hw2;


import java.util.Comparator;


/**
 * An implementation of {@link Sorter} that performs insertion sort
 * to sort the list.
 * 
 * @author David Helmick
 */
public class InsertionSorter extends Sorter
{
  @Override
  public void sort(WordList toSort, Comparator<String> comp) throws NullPointerException
  {
    int j = 1;
    while(j<toSort.length()) {
    	int k = j;
    	while(k>0 && comp.compare(toSort.get(k-1), toSort.get(k))==1) {
    		toSort.swap(k, k-1);
    		k--;
    	}
    	j++;
    }
  }
}
