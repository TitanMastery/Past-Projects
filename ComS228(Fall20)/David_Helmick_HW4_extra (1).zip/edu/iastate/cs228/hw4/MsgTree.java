package edu.iastate.cs228.hw4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
**@author David Helmick
**/
public class MsgTree {
	public char payloadChar;
	public MsgTree left;
	public MsgTree right;
	
	private static int totalCharacters = 0;
	
	//Need static char idx to the tree string for recursive solution
	private static int staticCharIdx = 0;
	
	//Constructor building the tree from a string
	public MsgTree(String encodingString) {
		payloadChar = encodingString.charAt(staticCharIdx);
		staticCharIdx++;
		char next = encodingString.charAt(staticCharIdx);
		if(next!='^') {
			left = new MsgTree(next);
			staticCharIdx++;
			next = encodingString.charAt(staticCharIdx);
			if(next!='^') {
				right = new MsgTree(next);
				staticCharIdx++;
			}
			else {
				right = new MsgTree(encodingString);
			}
		}
		else {
			left = new MsgTree(encodingString);
			if(staticCharIdx!=encodingString.length()) {
				if(encodingString.charAt(staticCharIdx) != '^') {
					right = new MsgTree(encodingString.charAt(staticCharIdx));
					staticCharIdx++;
				}
				else {
					right = new MsgTree(encodingString);
				}
			}
		}
		
	}
	
	//Constructor for a single node with null children
	public MsgTree(char payloadChar) {
		this.payloadChar = payloadChar;
		left = null;
		right = null;
	}
	
	//method to print characters and their binary codes
	public static void printCodes(MsgTree root, String code) {
		if(code=="") {
			System.out.println("character\tcode");
			System.out.println("-------------------------");
		}
		if(root.payloadChar!='^') {
			if(root.payloadChar=='\n') {
				System.out.println("   \\n\t\t"+code);
			}
			else {
				System.out.println("   "+root.payloadChar+"\t\t"+code);
			}
			return;
		}
		else {
			if(root.left!=null) {
				printCodes(root.left,code+"0");
			}
			if(root.right!=null) {
				printCodes(root.right,code+"1");
			}
		}
	}
	
	public void decode(MsgTree codes, String msg) {
		MsgTree currentNode = codes;
		for(int i=0;i<msg.length();i++) {
			if(msg.charAt(i) == '0') {
				currentNode = currentNode.left;
			}
			else if(msg.charAt(i) == '1') {
				currentNode = currentNode.right;
			}
			if(currentNode.payloadChar != '^') {
				System.out.print(currentNode.payloadChar);
				totalCharacters++;
				currentNode = codes;
			}
		}
		
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Please enter filename to decode: ");
		String fileName = scan.nextLine();
		File file = new File(fileName);
		scan.close();
		
		Scanner scanFile = null;
		try {
			scanFile = new Scanner(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String encodingString = scanFile.nextLine();
		String line2 = scanFile.nextLine();
		String msg = null;
		if(scanFile.hasNextLine()) {
			encodingString += "\n" + line2;
			msg = scanFile.nextLine();
		}
		else {
			msg = line2;
		}
		
		MsgTree root = new MsgTree(encodingString);
		printCodes(root, "");
		root.decode(root, msg);
		
		System.out.println("\nStatistics: ");
		System.out.println("Avg bits/char:\t\t"+(Math.round(10*(msg.length()/(double)totalCharacters)))/10.0);
		System.out.println("Total characters:\t"+totalCharacters);
		System.out.println("Space savings:\t\t"+(Math.round(10*((1-(msg.length()/((double)totalCharacters*16)))*100)))/10.0+"%");
	}
}