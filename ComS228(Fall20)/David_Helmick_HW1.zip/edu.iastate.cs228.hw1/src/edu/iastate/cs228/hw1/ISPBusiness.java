package edu.iastate.cs228.hw1;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author David Helmick
 *
 * The ISPBusiness class performs simulation over a grid 
 * plain with cells occupied by different TownCell types.
 *
 */
public class ISPBusiness {
	
	/**
	 * Returns a new Town object with updated grid value for next billing cycle.
	 * @param tOld: old/current Town object.
	 * @return: New town object.
	 */
	public static Town updatePlain(Town tOld) {
		Town tNew = new Town(tOld.getLength(), tOld.getWidth());
		
		for(int i = 0; i < tOld.getLength(); i++) {
			for(int j = 0; j < tOld.getWidth(); j++) {
				tNew.grid[i][j] = tOld.grid[i][j].next(tNew);
			}
		}
		
		return tNew;
	}
	
	/**
	 * Returns the profit for the current state in the town grid.
	 * @param town
	 * @return
	 */
	public static int getProfit(Town town) {
		int profit = 0;
		
		for(int i = 0; i < town.getLength(); i++) {
			for(int j = 0; j < town.getWidth(); j++) {
				if(town.grid[i][j].who() == State.CASUAL) {
					profit++;
				}
			}
		}
		
		return profit;
	}
	

	/**
	 * Main method. Interact with the user and ask if user wants to specify elements of grid
	 *  via an input file (option: 1) or wants to generate it randomly (option: 2).
	 *  
	 *  Depending on the user choice, create the Town object using respective constructor and
	 *  if user choice is to populate it randomly, then populate the grid here.
	 *  
	 *  Finally: For 12 billing cycle calculate the profit and update town object (for each cycle).
	 *  Print the final profit in terms of %. You should only print the integer part (Just print the 
	 *  integer value. Example if profit is 35.56%, your output should be just: 35).
	 *  
	 * Note that this method does not throws any exception, thus you need to handle all the exceptions
	 * in it.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String []args) {
		Scanner scan = new Scanner(System.in);
		int choice;
		Town town = null;
		
		do {
			System.out.println("How to populate grid (type 1 or 2): 1: from a file. 2: randomly with seed");
			choice = scan.nextInt();
		} while(choice!=1 && choice!=2);
		
		if(choice == 1) {
			while(true) {
				try {	
					System.out.println("Please enter file path:");
					String path = scan.next();
					town = new Town(path);
					break;
				} 
				catch (FileNotFoundException e) {
					System.out.println("File not found, try again");
				}
			}
		}
		else {
			System.out.println("Provide rows, cols and seed integer separated by spaces: ");
			
			int r = scan.nextInt();
			int c = scan.nextInt();
			int seed = scan.nextInt();
			
			town = new Town(r, c);
			town.randomInit(seed);
		}
		
		scan.close();
		
		int profit = getProfit(town);
		int totalProfit = town.getWidth() * town.getLength() * 12;
		
		for(int year = 1; year < 12; year++) {
			town = updatePlain(town);
			profit += getProfit(town);
		}
		
		double profitPercent = 100.0 * profit / totalProfit;
		System.out.println((int)profitPercent);
	}
}
