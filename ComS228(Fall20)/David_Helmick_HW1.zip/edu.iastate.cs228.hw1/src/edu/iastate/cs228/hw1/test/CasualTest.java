package edu.iastate.cs228.hw1.test;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import edu.iastate.cs228.hw1.*;

public class CasualTest {
	@Test
	public void CasualWhoTest() {
		TownCell s = new Casual(new Town(2,2), 1, 1);
		assertEquals(s.who(),State.CASUAL);
	}
	@Test
	public void CasualNextTest() {
		Town t = new Town(4,4);
		t.randomInit(10);
		Town tNew = t;
		t.grid[1][2].next(tNew);
		assertEquals(tNew.grid[1][2].who(),State.OUTAGE);
	}
}