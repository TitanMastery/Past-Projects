package edu.iastate.cs228.hw1;

/**
 * @author David Helmick
 *
 */
public class Streamer extends TownCell {

	/**
	 * @param p
	 * @param r
	 * @param c
	 */
	public Streamer(Town p, int r, int c) {
		super(p, r, c);
	}

	@Override
	public State who() {
		return State.STREAMER;
	}

	@Override
	public TownCell next(Town tNew) {
		TownCell nextCell = this;
		census(nCensus);
		if((nCensus[OUTAGE] <= 1 && nCensus[EMPTY] == 0) ||
				(nCensus[OUTAGE] == 0 && nCensus[EMPTY] <= 1)) {
			nextCell = new Reseller(tNew, row, col);
		}
		else if(nCensus[RESELLER] > 0) {
			nextCell = new Outage(tNew, row, col);
		}
		else if(nCensus[OUTAGE] > 0) {
			nextCell = new Empty(tNew, row, col);
		}
		else {
			plain = tNew;
		}
		
		return nextCell;
	}

}
