package edu.iastate.cs228.hw1.test;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import edu.iastate.cs228.hw1.*;

public class StreamerTest {
	@Test
	public void StreamerWhoTest() {
		TownCell s = new Streamer(new Town(2,2), 1, 1);
		assertEquals(s.who(),State.STREAMER);
	}
	@Test
	public void StreamerNextTest() {
		Town t = new Town(4,4);
		t.randomInit(10);
		Town tNew = t;
		t.grid[2][1].next(tNew);
		assertEquals(tNew.grid[2][1].who(),State.OUTAGE);
	}
}
