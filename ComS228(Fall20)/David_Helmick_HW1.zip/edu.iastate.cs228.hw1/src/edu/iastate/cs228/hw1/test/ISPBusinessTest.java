package edu.iastate.cs228.hw1.test;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import edu.iastate.cs228.hw1.*;

public class ISPBusinessTest {
	@Test
	public void GetProfitTest() {
		Town t = new Town(4,4);
		t.randomInit(10);
		assertEquals(ISPBusiness.getProfit(t),1);
	}
	@Test
	public void UpdatePlainTest() {
		Town t = new Town(4,4);
		t.randomInit(10);
		t = ISPBusiness.updatePlain(t);
		assertEquals(t.grid[0][0].who(),State.EMPTY);
		assertEquals(t.grid[1][1].who(),State.CASUAL);
		assertEquals(t.grid[2][2].who(),State.EMPTY);
		assertEquals(t.grid[3][3].who(),State.EMPTY);
	}
}