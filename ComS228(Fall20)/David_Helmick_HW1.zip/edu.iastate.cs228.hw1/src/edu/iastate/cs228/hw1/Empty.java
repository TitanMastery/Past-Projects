package edu.iastate.cs228.hw1;

/**
 * @author David Helmick
 *
 */
public class Empty extends TownCell {

	/**
	 * @param p
	 * @param r
	 * @param c
	 */
	public Empty(Town p, int r, int c) {
		super(p, r, c);
	}

	@Override
	public State who() {
		return State.EMPTY;
	}

	@Override
	public TownCell next(Town tNew) {
		TownCell nextCell;
		census(nCensus);
		if( (nCensus[OUTAGE] <= 1 && nCensus[EMPTY] == 0) ||
			(nCensus[OUTAGE] == 0 && nCensus[EMPTY] <= 1)) {
			nextCell = new Reseller(tNew, row, col);
		}
		else {
			nextCell = new Casual(tNew, row, col);
		}
		return nextCell;
	}

}
