package edu.iastate.cs228.hw1.test;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import edu.iastate.cs228.hw1.*;

public class TownTest {
	@Test
	public void RandomInitTest() {
		Town t = new Town(4,4);
		t.randomInit(10);
		assertEquals(t.grid[0][0].who(),State.OUTAGE);
		assertEquals(t.grid[1][1].who(),State.EMPTY);
		assertEquals(t.grid[2][2].who(),State.OUTAGE);
		assertEquals(t.grid[3][3].who(),State.RESELLER);
	}
	@Test
	public void GetLengthTest() {
		Town t = new Town(5,4);
		t.randomInit(10);
		assertEquals(t.getLength(),5);
	}
	@Test
	public void GetWidthTest() {
		Town t = new Town(5,4);
		t.randomInit(10);
		assertEquals(t.getWidth(),4);
	}
	@Test
	public void ToStringTest() {
		Town t = new Town(4,4);
		t.randomInit(10);
		assertEquals(t.toString(),"O\tR\tO\tR\t\nE\tE\tC\tO\t\nE\tS\tO\tS\t\nE\tO\tR\tR\t\n");
	}
}