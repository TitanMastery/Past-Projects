package edu.iastate.cs228.hw1.test;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import edu.iastate.cs228.hw1.*;

public class TownCellTest {
	@Test
	public void CensusTest() {
		Town t = new Town(4,4);
		t.randomInit(10);
		int[] nCensus = new int[5];
		t.grid[0][0].census(nCensus);
		assertEquals(t.grid[0][0].nCensus,new int[]{1,2,0,0,0});
	}
}